<?php

class Wyomind_Notificationmanager_Helper_Data extends Mage_Core_Helper_Data
{

}
